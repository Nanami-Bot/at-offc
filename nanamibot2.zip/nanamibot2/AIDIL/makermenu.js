const makermenu = (prefix) => { 
	return ` 
╭───「 *CREATOR MENU* 」───
│
├➲ *${prefix}sticker*
├➲ *${prefix}quotemaker [tx/wtrmk/tema]*
├➲ *${prefix}nulis [nama/kelas/text]*
├➲ *${prefix}trigger [reply image]*
├➲ *${prefix}rip [reply image]*
├➲ *${prefix}wasted [reply image]*
├➲ *${prefix}cphlogo [Aidil/Tipi]*
├➲ *${prefix}cglitch [Aidil/Tipi]*
├➲ *${prefix}cpubg [Aidil/Tipi]*
├➲ *${prefix}cml [???/Aidil]*
├➲ *${prefix}tahta [Aidil]*
├➲ *${prefix}croman [Aidil dan Bot]*
├➲ *${prefix}cthunder [Aidil]*
├➲ *${prefix}cbpink [Aidil]*
├➲ *${prefix}cmwolf [Aidil]*
├➲ *${prefix}csky [Aidil]*
├➲ *${prefix}cwooden [Aidil]*
├➲ *${prefix}cflower [Aidil]*
├➲ *${prefix}clove [Aidil]*
├➲ *${prefix}ccrossfire [Aidil]*
├➲ *${prefix}cnaruto [Aidil]*
├➲ *${prefix}cparty [Aidil]*
├➲ *${prefix}cshadow [Aidil]*
├➲ *${prefix}cminion [Aidil]*
├➲ *${prefix}cneon [Aidil]*
├➲ *${prefix}cneon2 [Aidil]*
├➲ *${prefix}cneongreen [Aidil]*
├➲ *${prefix}c3d [Aidil]*
├➲ *${prefix}csky [Aidil]*
├➲ *${prefix}tts [id Aidil]*
├➲ *${prefix}ttp [Aidil]*
├➲ *${prefix}slide [Aidil]*
├➲ *${prefix}stiker*
├➲ *${prefix}gifstiker*
├➲ *${prefix}toimg*
├➲ *${prefix}img2url*
├➲ *${prefix}nobg*
├➲ *${prefix}tomp3*
├➲ *${prefix}ocr*
│
╰──────────────────────

	           *©NANAMI-CHAN*`
	}
exports.makermenu = makermenu