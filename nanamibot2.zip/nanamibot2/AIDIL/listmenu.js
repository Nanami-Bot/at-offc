const listmenu = (prefix) => { 
	return ` *LIST MENU NANAMI-CHAN*
	
	
╭─「 *MEDIA DOWNLOADER* 」──
├➲ *${prefix}tiktokstalk [username]*
├➲ *${prefix}igstalk [ahmd.fdhl_]*
├➲ *${prefix}insta [Link]*
├➲ *${prefix}instastory [username]*
├➲ *${prefix}ssweb [url]*
├➲ *${prefix}url2img [Url]*
├➲ *${prefix}tiktok*
├➲ *${prefix}fototiktok*
├➲ *${prefix}meme*
├➲ *${prefix}memeindo*
├➲ *${prefix}kbbi*
├➲ *${prefix}wait*
├➲ *${prefix}trendtwit*
├➲ *${prefix}google [berita terkini]*
├➲ *${prefix}pinterest*
├➲ *${prefix}play*
╰─────────────────────

╭────「 *FUN & GAME* 」────
├➲ *${prefix}anjing*
├➲ *${prefix}kucing*
├➲ *${prefix}testime*
├➲ *${prefix}hilih*
├➲ *${prefix}say*
├➲ *${prefix}apakah*
├➲ *${prefix}kapankah*
├➲ *${prefix}bisakah*
├➲ *${prefix}rate*
├➲ *${prefix}watak*
├➲ *${prefix}hobby*
├➲ *${prefix}infogempa*
├➲ *${prefix}infonomor*
├➲ *${prefix}quotes*
├➲ *${prefix}truth*
├➲ *${prefix}dare*
├➲ *${prefix}katabijak*
├➲ *${prefix}fakta*
├➲ *${prefix}darkjokes*
├➲ *${prefix}bucin*
├➲ *${prefix}pantun*
├➲ *${prefix}katacinta*
├➲ *${prefix}jadwaltvnow*
├➲ *${prefix}hekerbucin*
├➲ *${prefix}katailham*
├➲ *${prefix}caklontong*
├➲ *${prefix}family100*
╰─────────────────────


╭─────────────────────
├➲ *${prefix}asupan*
├➲ *${prefix}tebakgambar*
├➲ *${prefix}caklontong*
├➲ *${prefix}family100*
├➲ *${prefix}kalkulator [13*12]*
├➲ *${prefix}wp [gunung]*
╰─────────────────────


╭───「 *OTHER & DEFACE* 」───
├➲ *${prefix}jarak [Klatem/Jogja]*
├➲ *${prefix}translate [en/Apa kabar?]*
├➲ *${prefix}pasangan [Aidil/???]*
├➲ *${prefix}gantengcek [Aidil]*
├➲ *${prefix}cantikcek [???]*
├➲ *${prefix}artinama [Aidil]*
├➲ *${prefix}persengay [???]*
├➲ *${prefix}pbucin [Aidil]*
├➲ *${prefix}bpfont [Aidil]*
├➲ *${prefix}textstyle [Aidil Tipi]*
├➲ *${prefix}jadwaltv [GTV]*
├➲ *${prefix}lirik [I am lady]*
├➲ *${prefix}chord [I am lady]*
├➲ *${prefix}wiki [Adolf Hitler]*
├➲ *${prefix}brainly [pertanyaan]*
├➲ *${prefix}resepmasakan [rawon]*
├➲ *${prefix}map [Klaten]*
├➲ *${prefix}film [The Walking Death]*
├➲ *${prefix}pinterest [gambar kucing]*
├➲ *${prefix}infocuaca [Klaten]*
├➲ *${prefix}jamdunia [Indonesia]*
├➲ *${prefix}mimpi [Bersamanya]*
├➲ *${prefix}infoalamat [jalan Klaten]*
╰─────────────────────


╭─────────────────────
├➲ *${prefix}asupan*
├➲ *${prefix}tebakgambar*
├➲ *${prefix}caklontong*
├➲ *${prefix}family100*
├➲ *${prefix}kalkulator [13*12]*
├➲ *${prefix}wp [gunung]*
╰─────────────────────

╭─────────────────────
├➲ *${prefix}jadwalsholat [Klaten]*
├➲ *${prefix}quran*
├➲ *${prefix}quransurah [1]*
├➲ *${prefix}tafsir [1/5]*
╰─────────────────────

╭─────────────────────
├➲ *${prefix}becrypt [string]*
├➲ *${prefix}encode64 [string]*
├➲ *${prefix}decode64 [encrypt]*
├➲ *${prefix}encode32 [string]*
├➲ *${prefix}decode32 [encrypt]*
├➲ *${prefix}encbinary [string]*
├➲ *${prefix}decbinary [encrypt]*
├➲ *${prefix}encoctal [string]*
├➲ *${prefix}decoctal [encrypt]*
├➲ *${prefix}hashidentifier [Encrypt Hash]*
├➲ *${prefix}dorking [dork]*
├➲ *${prefix}pastebin [teks]*
├➲ *${prefix}tinyurl [link]*
├➲ *${prefix}bitly [link]*
╰─────────────────────

╭───「 *CREATOR MENU* 」───
├➲ *${prefix}sticker*
├➲ *${prefix}quotemaker [tx/wtrmk/tema]*
├➲ *${prefix}nulis [nama/kelas/text]*
├➲ *${prefix}trigger [reply image]*
├➲ *${prefix}rip [reply image]*
├➲ *${prefix}wasted [reply image]*
├➲ *${prefix}cphlogo [Aidil/Tipi]*
├➲ *${prefix}cglitch [Aidil/Tipi]*
├➲ *${prefix}cpubg [Aidil/Tipi]*
├➲ *${prefix}cml [Aidil/Tipi]*
├➲ *${prefix}tahta [Aidil]*
├➲ *${prefix}croman [Aidil dan ???]*
├➲ *${prefix}cthunder [Aidil Tipi]*
├➲ *${prefix}cbpink [AidilTipi]*
├➲ *${prefix}cmwolf [Aidil Tipi]*
├➲ *${prefix}csky [Aidil Tipi]*
├➲ *${prefix}cwooden [Aidil Tipi]*
├➲ *${prefix}cflower [Aidil Tipi]*
├➲ *${prefix}clove [Aidil Tipi]*
├➲ *${prefix}ccrossfire [Aidil Tipi]*
├➲ *${prefix}cnaruto [Aidil Tipi]*
├➲ *${prefix}cparty [Aidil Tipi]*
├➲ *${prefix}cshadow [Aidil Tipi]*
├➲ *${prefix}cminion [Aidil Tipi]*
├➲ *${prefix}cneon [Aidil Tipi]*
├➲ *${prefix}cneon2 [Aidil Tipi]*
├➲ *${prefix}cneongreen [Aidil Tipi]*
├➲ *${prefix}c3d [Aidil Tipi]*
├➲ *${prefix}csky [Aidil Tipi]*
├➲ *${prefix}tts [id Haii]*
├➲ *${prefix}ttp [Aidil Tipi]*
├➲ *${prefix}slide [Aidil Tipi]*
├➲ *${prefix}stiker*
├➲ *${prefix}gifstiker*
├➲ *${prefix}toimg*
├➲ *${prefix}img2url*
├➲ *${prefix}nobg*
├➲ *${prefix}tomp3*
├➲ *${prefix}ocr*
╰──────────────────────

╭──────「 *GROUP ONLY* 」───
├➲ *${prefix}modeanime [On/Off]*
├➲ *${prefix}naruto*
├➲ *${prefix}minato*
├➲ *${prefix}boruto*
├➲ *${prefix}hinata*
├➲ *${prefix}sakura*
├➲ *${prefix}sasuke*
├➲ *${prefix}kaneki*
├➲ *${prefix}toukachan*
├➲ *${prefix}rize*
├➲ *${prefix}akira*
├➲ *${prefix}itori*
├➲ *${prefix}kurumi*
├➲ *${prefix}miku*
├➲ *${prefix}anime*
├➲ *${prefix}animecry*
├➲ *${prefix}neonime*
├➲ *${prefix}animekiss*
├➲ *${prefix}wink*
╰─────────────────────

╭─────────────────────
├➲ *${prefix}welcome [On/Off]*
├➲ *${prefix}grup [buka/tutup]*
├➲ *${prefix}antilink [on/off*
├➲ *${prefix}ownergrup*
├➲ *${prefix}setpp*
├➲ *${prefix}infogc*
├➲ *${prefix}add*
├➲ *${prefix}kick*
├➲ *${prefix}promote*
├➲ *${prefix}demote*
├➲ *${prefix}setname*
├➲ *${prefix}setdesc*
├➲ *${prefix}linkgrup*
├➲ *${prefix}tagme*
├➲ *${prefix}hidetag*
├➲ *${prefix}tagall*
├➲ *${prefix}mentionall*
├➲ *${prefix}fitnah*
├➲ *${prefix}listadmin*
├➲ *${prefix}openanime*
├➲ *${prefix}edotense*
╰──────────────────────

╭──────────────────────
├➲ *${prefix}nsfw [On/Off]*
├➲ *${prefix}nsfwloli*
├➲ *${prefix}nsfwblowjob*
├➲ *${prefix}nsfwneko*
├➲ *${prefix}nsfwtrap*
├➲ *${prefix}hentai*
├➲ *${prefix}simih [On/Off]*
╰──────────────────────

╭────「 *OWNER ONLY* 」─────
├➲ *${prefix}addprem [mentioned]*
├➲ *${prefix}removeprem [mention]*
├➲ *${prefix}setppbot*
├➲ *${prefix}setreply*
├➲ *${prefix}bc*
├➲ *${prefix}bcgc*
├➲ *${prefix}ban*
├➲ *${prefix}unban*
├➲ *${prefix}block*
├➲ *${prefix}unblock*
├➲ *${prefix}clearall*
├➲ *${prefix}delete*
├➲ *${prefix}clone*
├➲ *${prefix}getses*
├➲ *${prefix}leave*
╰──────────────────────


╭─────「 *PREMIUM ONLY* 」───
├➲ *${prefix}playmp3 [I am Lady]*
├➲ *${prefix}fb [link video]*
├➲ *${prefix}snack [link snack video]*
├➲ *${prefix}ytmp3 [link yt]*
├➲ *${prefix}ytmp4 [link yt]*
├➲ *${prefix}joox [Monolog Pamungkas]*
├➲ *${prefix}smule [Link Video Smule]*
├➲ *${prefix}cersex*
├➲ *${prefix}asupan*
├➲ *${prefix}xxx [japan]*
├➲ *${prefix}pornhub [GangBang]*
├➲ *${prefix}hentai [Random]*
├➲ *${prefix}ban [TagUser]*
├➲ *${prefix}unban [TagUser]*
├➲ *${prefix}bc [teks]*
├➲ *${prefix}asupan*
╰──────────────────────

	
               *©NANAMI-CHAN*`
	}
exports.listmenu = listmenu